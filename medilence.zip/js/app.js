const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');

const app = express();
const PORT = 3000;

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

// Routes for HTML pages
app.get('/', (req, res) => res.redirect('/login'));
app.get('/login', (req, res) => res.sendFile(path.join(__dirname, 'views/login.html')));
app.get('/register', (req, res) => res.sendFile(path.join(__dirname, 'views/register.html')));
app.get('/forgot', (req, res) => res.sendFile(path.join(__dirname, 'views/forgot.html')));

// Dummy POST route (just log form data)
app.post('/login', (req, res) => {
  console.log('Login form data:', req.body);
  res.send('Login submitted!');
});

app.post('/register', (req, res) => {
  console.log('Register form data:', req.body);
  res.send('Registration submitted!');
});

app.post('/forgot', (req, res) => {
  console.log('Forgot Password email:', req.body);
  res.send('Reset link sent!');
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
