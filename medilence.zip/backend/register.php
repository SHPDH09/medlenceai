<?php
include 'db.php'; // connects to your Aiven DB
require_once 'table.php';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name     = trim($_POST['fullname']);
    $email    = trim($_POST['email']);
    $phone    = trim($_POST['phone']);
    $password = trim($_POST['password']);
    $confirm  = trim($_POST['confirm_password']);

    // Check for empty fields
    if (empty($name) || empty($email) || empty($phone) || empty($password) || empty($confirm)) {
        die("Please fill all fields.");
    }

    // Confirm password match
    if ($password !== $confirm) {
        die("Passwords do not match.");
    }

    // Check if user already exists
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows > 0) {
        die("Email already registered.");
    }

    // Hash the password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Insert user into database
    $insert = $conn->prepare("INSERT INTO users (name, email, phone, password) VALUES (?, ?, ?, ?)");
    $insert->bind_param("ssss", $name, $email, $phone, $hashed_password);
    
    if ($insert->execute()) {
        header("Location: index.html?register=success");
        exit();
    } else {
        die("Registration failed. Try again.");
    }
}
?>
