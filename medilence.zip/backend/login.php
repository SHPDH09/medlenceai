<?php
session_start();
include 'db.php'; // Include the DB connection file
require_once 'table.php';
// Fetch form values
$email = $_POST['email'];
$password = $_POST['password'];

// Validate input
if (empty($email) || empty($password)) {
    echo "Please fill in all fields.";
    exit();
}

// Query to match user
$sql = "SELECT * FROM users WHERE email='$email' OR mobile='$email' LIMIT 1";
$result = mysqli_query($conn, $sql);

if ($row = mysqli_fetch_assoc($result)) {
    if ($row['password'] === $password) {
        // Login successful
        $_SESSION['username'] = $row['name'];
        header("Location: dashboard.php");
        exit();
    } else {
        echo "Incorrect password.";
    }
} else {
    echo "User not found.";
}

mysqli_close($conn);
?>
